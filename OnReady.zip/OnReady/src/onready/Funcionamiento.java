package onready;

public interface Funcionamiento {
    
    public void encender();
    public void acelerar();
    public void frenar();
    public void apagar();
    
}
